<?php
/**
 * @codeCoverageIgnore
 */
echo Yii::t('extensions-manager', 'No active extensions to configure');