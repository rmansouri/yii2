<?php
/**
 * @codeCoverageIgnore
 */
return [
    [
        'sectionName' => 'Extensions manager',
        'configurationView' => 'src/views/_configuration.php',
        'configurationModel' => 'DevGroup\ExtensionsManager\models\ExtensionsConfiguration',
    ],
];
