<?php
return [
    'fakedev2/yii2-fake-ext2' => [
        'composer_name' => 'fakedev2/yii2-fake-ext2',
        'composer_type' => 'yii2-extension',
        'is_active' => 0,
        'is_core' => 0,
    ],
    'fakedev2/yii2-fake-ext4' => [
        'composer_name' => 'fakedev2/yii2-fake-ext4',
        'composer_type' => 'yii2-extension',
        'is_active' => 1,
        'is_core' => 0,
    ],
];