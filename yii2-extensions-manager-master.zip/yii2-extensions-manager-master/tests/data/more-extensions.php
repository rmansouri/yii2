<?php
return [
    'fakedev/yii2-fake-ext' => [
        'composer_name' => 'fakedev/yii2-fake-ext',
        'composer_type' => 'yii2-extension',
        'is_active' => 0,
        'is_core' => 0,
    ],
    'fakedev/yii2-fake-ext3' => [
        'composer_name' => 'fakedev/yii2-fake-ext3',
        'composer_type' => 'yii2-extension',
        'is_active' => 0,
        'is_core' => 1,
    ],
    'fakedev2/yii2-fake-ext2' => [
        'composer_name' => 'fakedev2/yii2-fake-ext2',
        'composer_type' => 'yii2-extension',
        'is_active' => 0,
        'is_core' => 0,
    ],
    'fakedev2/yii2-fake-ext4' => [
        'composer_name' => 'fakedev2/yii2-fake-ext4',
        'composer_type' => 'yii2-extension',
        'is_active' => 1,
        'is_core' => 0,
    ],
    'dev/fake-ext5' => [
        'composer_name' => 'dev/fake-ext5',
        'composer_type' => 'yii2-extension',
        'is_active' => 1,
        'is_core' => 0,
    ],
    'dev/fake-ext6' => [
        'composer_name' => 'dev/fake-ext6',
        'composer_type' => 'yii2-extension',
        'is_active' => 0,
        'is_core' => 0,
    ],
];