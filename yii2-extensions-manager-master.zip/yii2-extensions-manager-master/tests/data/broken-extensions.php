<?php
return [
    'broken/extension1' => [
        'composer_name' => 'broken/extension1',
    ],
    'broken/extension2' => [
        'is_core' => 'no',
    ],
    'broken/extension3' => [
        'is_active' => null,
    ],
];