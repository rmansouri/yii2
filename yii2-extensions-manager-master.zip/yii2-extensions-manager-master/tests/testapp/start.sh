#!/bin/sh

cd web;
cliserver=1 php -S 127.0.0.1:9911 routing.php


